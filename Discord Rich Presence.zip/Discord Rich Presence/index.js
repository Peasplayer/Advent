const RPC = require('discord-rpc')
const { start } = require('repl')
const config = require('./config.json')
const rpc = new RPC.Client({
    transport: "ipc"
})

rpc.on("ready", async () => {
    rpc.setActivity({
        details: config.details,
        state: config.state,
        startTimestamp: new Date(),
        largeImageKey: config.largeImage,
        largeImageText: config.largeImageText,
        smallImageKey: config.smallImage,
        smallImageText: config.smallImageText,
        partySize: config.players,
        partyMax: config.maxPlayers
    })
    console.log("Eingeloggt in User " + rpc.user.username)
})

rpc.login({
    clientId: config.clientId
})